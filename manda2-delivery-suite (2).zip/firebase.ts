// Mocking Firebase for environment where modules are missing or broken
// The errors indicate that the 'firebase' package is either not installed or incompatible versions are present.
// We fallback to a full "Mock Mode".

export const db = {} as any;
export const auth = {} as any;
export const analytics = {} as any;

// Flag to tell the app we are using Mock Mode
export const shouldUseFirebase = false; 
