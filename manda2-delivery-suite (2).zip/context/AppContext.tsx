import React, { createContext, useContext, useState, useEffect } from 'react';
import { db, auth, shouldUseFirebase } from '../firebase';

// --- TIPOS DE DATOS ---
export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'on_way' | 'delivered';
export type VehicleType = 'bici' | 'moto' | 'auto';

// Local definition of User to replace firebase/auth User
export interface User {
    uid: string;
    email: string | null;
    displayName?: string | null;
    photoURL?: string | null;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category: string;
  active: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'rider' | 'merchant' | 'system';
  text: string;
  timestamp: Date;
}

export interface Chat {
  id: string;
  orderId: string;
  type: 'rider_client' | 'merchant_client';
  messages: ChatMessage[];
}

export interface Transaction {
  id: string;
  orderId: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  userRole: 'rider' | 'merchant' | 'platform';
  targetAlias?: string; // Nuevo campo para el Split
  timestamp: Date;
}

export interface Order {
  id: string;
  customer: string;
  merchant: string;
  items: Product[];
  total: number;
  status: OrderStatus;
  vehicleType: VehicleType;
  riderFee: number;
  platformFee: number; 
  merchantEarnings: number;
  timestamp: Date;
  chatIdRider?: string;
  paymentMethod?: 'mercadopago' | 'cash';
}

export interface PaymentAliases {
    platform: string;
    rider: string;
    merchant: string;
}

interface AppContextType {
  user: User | null;
  loadingAuth: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  
  products: Product[];
  orders: Order[];
  activeOrder: Order | null;
  riderVehicle: VehicleType;
  chats: Chat[];
  transactions: Transaction[];
  paymentAliases: PaymentAliases;
  
  addProduct: (product: Omit<Product, 'id'>) => void;
  deleteProduct: (id: string) => void;
  toggleProductStatus: (id: string) => void;
  placeOrder: (cartItems: Product[], paymentMethod: 'mercadopago' | 'cash') => Promise<void>;
  updateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  setRiderVehicle: (vehicle: VehicleType) => void;
  sendMessage: (chatId: string, text: string, sender: ChatMessage['sender']) => void;
  getChat: (chatId: string) => Chat | undefined;
  formatPrice: (amount: number) => string;
  updatePaymentAlias: (role: keyof PaymentAliases, alias: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// --- MOCK DATA FOR DEMO MODE ---
const MOCK_PRODUCTS: Product[] = [
  { id: 'p1', name: 'Hamburguesa Doble', price: 4500, description: 'Doble carne, cheddar, bacon y salsa especial.', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=500&q=60', category: 'Comida', active: true },
  { id: 'p2', name: 'Pizza Pepperoni', price: 5200, description: 'Muzzarella abundante y pepperoni de primera.', image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=500&q=60', category: 'Comida', active: true },
  { id: 'p3', name: 'Papas Fritas', price: 2000, description: 'Porción grande crocante.', image: 'https://images.unsplash.com/photo-1630384060421-a431e4cad29e?auto=format&fit=crop&w=500&q=60', category: 'Comida', active: true },
  { id: 'p4', name: 'Coca Cola 1.5L', price: 1800, description: 'Refrescante.', image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=500&q=60', category: 'Bebidas', active: true },
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [chats, setChats] = useState<Chat[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [riderVehicle, setRiderVehicle] = useState<VehicleType>('moto');
  
  // Estado para almacenar los Aliases (en una app real iría a la DB del usuario)
  const [paymentAliases, setPaymentAliases] = useState<PaymentAliases>({
      platform: 'manda2.admin.mp',
      rider: '',
      merchant: ''
  });

  // --- AUTHENTICATION (MOCK) ---
  useEffect(() => {
    // In Mock Mode we don't wait for firebase
    setLoadingAuth(false);
  }, []);

  const login = async (email: string, pass: string) => {
       console.log("Mock Login Success");
       setUser({ email, uid: 'mock-user-id' } as User);
  };

  const register = async (email: string, pass: string) => {
       console.log("Mock Register Success");
       setUser({ email, uid: 'mock-user-id' } as User);
  };

  const logout = async () => {
      setUser(null);
  };

  // --- INITIALIZATION (MOCK) ---
  useEffect(() => {
      setProducts(MOCK_PRODUCTS);
  }, []);

  // --- ACTIONS (MOCK) ---

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', minimumFractionDigits: 0 }).format(amount);
  };

  const updatePaymentAlias = (role: keyof PaymentAliases, alias: string) => {
      setPaymentAliases(prev => ({ ...prev, [role]: alias }));
  };

  const addProduct = async (product: Omit<Product, 'id'>) => {
      const newProduct = { ...product, id: `mock-p-${Date.now()}` };
      setProducts(prev => [...prev, newProduct]);
  };

  const deleteProduct = async (id: string) => {
      setProducts(prev => prev.map(p => p.id === id ? { ...p, active: false } : p));
  };

  const toggleProductStatus = async (id: string) => {
      setProducts(prev => prev.map(p => p.id === id ? { ...p, active: !p.active } : p));
  };

  const placeOrder = async (cartItems: Product[], paymentMethod: 'mercadopago' | 'cash') => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.price, 0);
    const deliveryFee = 3500; 
    const total = subtotal + deliveryFee;

    // --- LÓGICA DE SPLIT DE PAGOS ---
    const riderShare = 2000; 
    const platformShare = 1500; 
    const merchantShare = subtotal; 

    const mockChatId = `chat-${Date.now()}`;
    const mockOrderId = `order-${Date.now()}`;
    const customerName = user?.email?.split('@')[0] || 'Usuario Demo';

    const newChat: Chat = {
      id: mockChatId,
      orderId: mockOrderId,
      type: 'rider_client',
      messages: [{ id: 'sys', sender: 'system', text: 'Chat Demo', timestamp: new Date() }]
    };
    setChats(prev => [...prev, newChat]);

    const newOrder: Order = {
      id: mockOrderId,
      customer: customerName,
      merchant: 'Mi Negocio Online',
      items: cartItems,
      total: total,
      status: 'pending',
      vehicleType: 'moto',
      riderFee: riderShare,
      platformFee: platformShare,
      merchantEarnings: merchantShare,
      paymentMethod: paymentMethod,
      timestamp: new Date(),
      chatIdRider: mockChatId
    };
    setOrders(prev => [newOrder, ...prev]);
    setActiveOrder(newOrder);
  };

  const updateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
      setActiveOrder(prev => prev && prev.id === orderId ? { ...prev, status: newStatus } : prev);

      const order = orders.find(o => o.id === orderId);

      if (newStatus === 'on_way' && order?.chatIdRider) {
         sendMessage(order.chatIdRider, '¡Voy en camino con tu pedido!', 'rider');
      }

      // --- SIMULACIÓN DE SPLIT PAYMENT DE MERCADO PAGO ---
      if (newStatus === 'delivered' && order) {
          const ts = new Date();
          
          const riderTarget = paymentAliases.rider || 'cuenta.rider.mp';
          const merchantTarget = paymentAliases.merchant || 'cuenta.comercio.mp';
          const platformTarget = paymentAliases.platform;

          const txs: Transaction[] = [
              {
                  id: `tx-${Date.now()}-1`,
                  orderId: order.id,
                  type: 'credit',
                  amount: order.riderFee,
                  description: `Split MP: Envío a ${riderTarget}`,
                  userRole: 'rider',
                  targetAlias: riderTarget,
                  timestamp: ts
              },
              {
                  id: `tx-${Date.now()}-2`,
                  orderId: order.id,
                  type: 'credit',
                  amount: order.merchantEarnings,
                  description: `Split MP: Venta a ${merchantTarget}`,
                  userRole: 'merchant',
                  targetAlias: merchantTarget,
                  timestamp: ts
              },
              {
                  id: `tx-${Date.now()}-3`,
                  orderId: order.id,
                  type: 'credit',
                  amount: order.platformFee,
                  description: `Split MP: Comisión a ${platformTarget}`,
                  userRole: 'platform',
                  targetAlias: platformTarget,
                  timestamp: ts
              }
          ];

          setTransactions(prev => [...txs, ...prev]);
      }
  };

  const sendMessage = async (chatId: string, text: string, sender: ChatMessage['sender']) => {
    const newMessage = {
        id: `msg-${Date.now()}`,
        sender,
        text,
        timestamp: new Date()
    };

    setChats(prev => prev.map(c => c.id === chatId ? { ...c, messages: [...c.messages, newMessage as ChatMessage] } : c));
  };

  const getChat = (chatId: string) => {
    return chats.find(c => c.id === chatId);
  };

  return (
    <AppContext.Provider value={{ 
      user,
      loadingAuth,
      login,
      register,
      logout,
      products,
      orders, 
      activeOrder,
      riderVehicle,
      chats,
      transactions,
      paymentAliases,
      addProduct,
      deleteProduct,
      toggleProductStatus,
      placeOrder, 
      updateOrderStatus, 
      setRiderVehicle,
      sendMessage,
      getChat,
      formatPrice,
      updatePaymentAlias
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
